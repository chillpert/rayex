var _api_8cpp =
[
    [ "currentFrame", "_api_8cpp.html#af5d0cc455cab9794ad7d46a006042f30", null ],
    [ "deviceExtensions", "_api_8cpp.html#ae1e6f0cd8aa9c6f10c6ffae2320f267d", null ],
    [ "layers", "_api_8cpp.html#acfb56bba9609d86c6ba574d168328150", null ],
    [ "maxFramesInFlight", "_api_8cpp.html#a227f0a65a526b6b4517a557cf1db9c7d", null ]
];