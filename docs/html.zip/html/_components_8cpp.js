var _components_8cpp =
[
    [ "g_device", "_components_8cpp.html#af79af13d89e6750c84e1abba095f111d", null ],
    [ "g_dynamicLoader", "_components_8cpp.html#a0f9987b483a0e6544bfd6aeb45cb3a12", null ],
    [ "g_graphicsCmdPool", "_components_8cpp.html#ae0ed4cdd2a322cd9eabbefc9fe1cd789", null ],
    [ "g_graphicsFamilyIndex", "_components_8cpp.html#a293d2cff449b4f7a9a818139ac804c24", null ],
    [ "g_graphicsQueue", "_components_8cpp.html#af6e9ac110b43e325c90fa487e80cd7cc", null ],
    [ "g_instance", "_components_8cpp.html#a2a6631357a4950ac30f9491c53b249f2", null ],
    [ "g_physicalDevice", "_components_8cpp.html#a3bba8e931280440c523b5e01abca7a66", null ],
    [ "g_physicalDeviceLimits", "_components_8cpp.html#a7a45dde822191d473bf2d48b4f1989d6", null ],
    [ "g_shaderGroups", "_components_8cpp.html#a0c0af0cfcc3c14f7f4fe48065581be2d", null ],
    [ "g_surface", "_components_8cpp.html#a2e6be14fb5dfecb4f55aaabb40320b90", null ],
    [ "g_surfaceFormat", "_components_8cpp.html#a383c91796e541f9c2638655c6795d1a6", null ],
    [ "g_swapchain", "_components_8cpp.html#a25f4cf185df34819bc1126b3b67eb3c7", null ],
    [ "g_swapchainImageCount", "_components_8cpp.html#a19647ba4f4e9b78d73b93a3fc417d16e", null ],
    [ "g_swapchainImageViews", "_components_8cpp.html#a061c6006b71019792f3b5c14257fdaa2", null ],
    [ "g_transferCmdPool", "_components_8cpp.html#a1ffed93078e1a52f19a95712f718e069", null ],
    [ "g_transferFamilyIndex", "_components_8cpp.html#aecb50d18eceff6c8d47f3c0f0e0ea006", null ],
    [ "g_transferQueue", "_components_8cpp.html#a1368884f2e836d2d000898052c5fd912", null ],
    [ "g_window", "_components_8cpp.html#a125bfd0bedca67d2df1c1cc90d63df48", null ]
];