var _vertex_8hpp =
[
    [ "GLENABLE_EXPERIMENTAL", "_vertex_8hpp.html#ab7b56463f2ca50b08e1c0e1080dced5a", null ]
];