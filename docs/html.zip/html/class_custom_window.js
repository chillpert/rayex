var class_custom_window =
[
    [ "CustomWindow", "class_custom_window.html#aeae35d36099dced85ad64e1f097a5fe7", null ],
    [ "init", "class_custom_window.html#a850b86f73d9458a0a6b98b15b2ae655b", null ],
    [ "setCamera", "class_custom_window.html#a87bed33494862982588d180e5fde0e98", null ],
    [ "update", "class_custom_window.html#ac0b3f3bfe1b98bf47b67a332794462e3", null ]
];