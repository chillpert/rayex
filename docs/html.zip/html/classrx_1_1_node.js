var classrx_1_1_node =
[
    [ "Node", "classrx_1_1_node.html#adf0d15a58309c1fdb7cff60a5a4e10f5", null ],
    [ "~Node", "classrx_1_1_node.html#a11793f57afaf9c34a42ac6efc5a40049", null ],
    [ "getID", "classrx_1_1_node.html#a44d70a683c0103419a22aa7a816c65d2", null ]
];