var classrx_1_1_queues =
[
    [ "init", "classrx_1_1_queues.html#ab003c434f6c993f2381b6b0c9dd76003", null ],
    [ "retrieveHandles", "classrx_1_1_queues.html#a3262a78b46dd3d20f720c256beee4c68", null ]
];