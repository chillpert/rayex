var classrx_1_1_surface =
[
    [ "Surface", "classrx_1_1_surface.html#affa337798c1890c91b253af4f69490d3", null ],
    [ "Surface", "classrx_1_1_surface.html#acd2225f3afbbe22dee2b27b6367efb9e", null ],
    [ "~Surface", "classrx_1_1_surface.html#aee862bb3e7ca8bac54d1c3e042bc09e4", null ],
    [ "checkSettingSupport", "classrx_1_1_surface.html#a484056000f32d20351f88b9641aa5989", null ],
    [ "getCapabilities", "classrx_1_1_surface.html#a31f2bf06d6901c5dade699be5d687764", null ],
    [ "getColorSpace", "classrx_1_1_surface.html#a7e5228e635dd842094fe5be7559bd5be", null ],
    [ "getFormat", "classrx_1_1_surface.html#aa43569014a536a35d9b356f18e1cf61e", null ],
    [ "getPresentMode", "classrx_1_1_surface.html#a7366a6bee8a6783490edcf49d6402182", null ],
    [ "init", "classrx_1_1_surface.html#a76b3c2a398b71c3455eea9f82a60ce75", null ]
];