var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "api", "dir_da61e3e9a357748887e3ca8d7c5a0c16.html", "dir_da61e3e9a357748887e3ca8d7c5a0c16" ],
    [ "base", "dir_0af1587c8378955de40f48b4bd1869f0.html", "dir_0af1587c8378955de40f48b4bd1869f0" ],
    [ "example", "dir_1ff95392bc4e65547c61a42698fda530.html", "dir_1ff95392bc4e65547c61a42698fda530" ],
    [ "pch", "dir_4352f877eacf8987ed9e54d8b8506651.html", "dir_4352f877eacf8987ed9e54d8b8506651" ],
    [ "window", "dir_c7f79d9fead0a70cab4af348b59fbdf1.html", "dir_c7f79d9fead0a70cab4af348b59fbdf1" ],
    [ "Core.hpp", "_core_8hpp.html", "_core_8hpp" ],
    [ "Renderer.cpp", "_renderer_8cpp.html", null ],
    [ "Renderer.hpp", "_renderer_8hpp.html", null ],
    [ "Settings.cpp", "_settings_8cpp.html", null ],
    [ "Settings.hpp", "_settings_8hpp.html", [
      [ "Settings", "classrx_1_1_settings.html", null ]
    ] ]
];