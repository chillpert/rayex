var dir_f85b151042f4410f72e459bf14a2debf =
[
    [ "Device.cpp", "_device_8cpp.html", null ],
    [ "Device.hpp", "_device_8hpp.html", null ],
    [ "PhysicalDevice.cpp", "_physical_device_8cpp.html", "_physical_device_8cpp" ],
    [ "PhysicalDevice.hpp", "_physical_device_8hpp.html", "_physical_device_8hpp" ]
];