var structrx_1_1_camera_ubo =
[
    [ "m_projection", "structrx_1_1_camera_ubo.html#aee753c7caffeee39f74882ac0efabd36", null ],
    [ "m_projectionInverse", "structrx_1_1_camera_ubo.html#a9baf3056ebfa633c7fa9297a4e54820b", null ],
    [ "m_view", "structrx_1_1_camera_ubo.html#a21fc9f616f25f3323dda0c6222c835d5", null ],
    [ "m_viewInverse", "structrx_1_1_camera_ubo.html#ab1aec705f8a6ec1a2ea12772f561c52d", null ]
];