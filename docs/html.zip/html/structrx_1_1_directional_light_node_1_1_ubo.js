var structrx_1_1_directional_light_node_1_1_ubo =
[
    [ "m_ambient", "structrx_1_1_directional_light_node_1_1_ubo.html#a0a58156258d333466f999608b2e22a7e", null ],
    [ "m_diffuse", "structrx_1_1_directional_light_node_1_1_ubo.html#a8bf4620e09d9c39636094bc24569a6ca", null ],
    [ "m_direction", "structrx_1_1_directional_light_node_1_1_ubo.html#a1cfdf419d634090203c5be11c5d6b361", null ],
    [ "m_specular", "structrx_1_1_directional_light_node_1_1_ubo.html#acf6f110c158403d5b8c7be3ae9e801ff", null ]
];