var structrx_1_1_mvp_ubo =
[
    [ "cameraPos", "structrx_1_1_mvp_ubo.html#a124a3f6f6f8f892c9220ae9f05c41056", null ],
    [ "model", "structrx_1_1_mvp_ubo.html#a6dcf61536d4558874e3c0c89463fa0ab", null ],
    [ "projection", "structrx_1_1_mvp_ubo.html#aaf2668b8fd415c88c3f06a98ee92db2b", null ],
    [ "view", "structrx_1_1_mvp_ubo.html#a1743bbce71e239d041c8579f8503c2ae", null ]
];