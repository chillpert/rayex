var structrx_1_1_point_light_node_1_1_ubo =
[
    [ "m_ambient", "structrx_1_1_point_light_node_1_1_ubo.html#a4e6f1424bdbba910eef6f53af6350cca", null ],
    [ "m_constant", "structrx_1_1_point_light_node_1_1_ubo.html#ad3b9c716606b2ec68b0872ba376d5b4a", null ],
    [ "m_diffuse", "structrx_1_1_point_light_node_1_1_ubo.html#a60fb614f44c9cbd09cc54ee9a7810554", null ],
    [ "m_linear", "structrx_1_1_point_light_node_1_1_ubo.html#a4de7307b5506625869696bb603a202fb", null ],
    [ "m_position", "structrx_1_1_point_light_node_1_1_ubo.html#ab800f79021718c3ce8e9f91fb421432a", null ],
    [ "m_quadratic", "structrx_1_1_point_light_node_1_1_ubo.html#abc079cca86d4f938628c91b84b344e42", null ],
    [ "m_specular", "structrx_1_1_point_light_node_1_1_ubo.html#a2d8f9d3c7880eb561c554e9cb4a802f7", null ]
];