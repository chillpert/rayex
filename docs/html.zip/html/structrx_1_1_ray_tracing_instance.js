var structrx_1_1_ray_tracing_instance =
[
    [ "m_modelIndex", "structrx_1_1_ray_tracing_instance.html#af2aab6193d7ec0ebbbebbbb38ca2469c", null ],
    [ "m_textureOffset", "structrx_1_1_ray_tracing_instance.html#a0de362f470d88095cacf6243682a8eb2", null ]
];