var _base_8hpp =
[
    [ "Material", "struct_r_a_y_e_x_e_c___n_a_m_e_s_p_a_c_e_1_1_material.html", "struct_r_a_y_e_x_e_c___n_a_m_e_s_p_a_c_e_1_1_material" ],
    [ "Mesh", "struct_r_a_y_e_x_e_c___n_a_m_e_s_p_a_c_e_1_1_mesh.html", "struct_r_a_y_e_x_e_c___n_a_m_e_s_p_a_c_e_1_1_mesh" ],
    [ "Geometry", "struct_r_a_y_e_x_e_c___n_a_m_e_s_p_a_c_e_1_1_geometry.html", "struct_r_a_y_e_x_e_c___n_a_m_e_s_p_a_c_e_1_1_geometry" ],
    [ "GeometryInstance", "struct_r_a_y_e_x_e_c___n_a_m_e_s_p_a_c_e_1_1_geometry_instance.html", "struct_r_a_y_e_x_e_c___n_a_m_e_s_p_a_c_e_1_1_geometry_instance" ],
    [ "Light", "struct_r_a_y_e_x_e_c___n_a_m_e_s_p_a_c_e_1_1_light.html", "struct_r_a_y_e_x_e_c___n_a_m_e_s_p_a_c_e_1_1_light" ],
    [ "DirectionalLight", "struct_r_a_y_e_x_e_c___n_a_m_e_s_p_a_c_e_1_1_directional_light.html", "struct_r_a_y_e_x_e_c___n_a_m_e_s_p_a_c_e_1_1_directional_light" ],
    [ "PointLight", "struct_r_a_y_e_x_e_c___n_a_m_e_s_p_a_c_e_1_1_point_light.html", "struct_r_a_y_e_x_e_c___n_a_m_e_s_p_a_c_e_1_1_point_light" ],
    [ "instance", "_base_8hpp.html#abb8acb5237813d1ac88e190a79a1bff2", null ],
    [ "loadObj", "_base_8hpp.html#a02a95a02aa5d57299c4eecb3c6bb4d3d", null ]
];