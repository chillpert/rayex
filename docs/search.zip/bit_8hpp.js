var bit_8hpp =
[
    [ "highestBitValue", "bit_8hpp.html#ga0dcc8fe7c3d3ad60dea409281efa3d05", null ],
    [ "highestBitValue", "bit_8hpp.html#ga898ef075ccf809a1e480faab48fe96bf", null ],
    [ "lowestBitValue", "bit_8hpp.html#ga2ff6568089f3a9b67f5c30918855fc6f", null ],
    [ "powerOfTwoAbove", "bit_8hpp.html#ga8cda2459871f574a0aecbe702ac93291", null ],
    [ "powerOfTwoAbove", "bit_8hpp.html#ga2bbded187c5febfefc1e524ba31b3fab", null ],
    [ "powerOfTwoBelow", "bit_8hpp.html#ga3de7df63c589325101a2817a56f8e29d", null ],
    [ "powerOfTwoBelow", "bit_8hpp.html#gaf78ddcc4152c051b2a21e68fecb10980", null ],
    [ "powerOfTwoNearest", "bit_8hpp.html#ga5f65973a5d2ea38c719e6a663149ead9", null ],
    [ "powerOfTwoNearest", "bit_8hpp.html#gac87e65d11e16c3d6b91c3bcfaef7da0b", null ]
];