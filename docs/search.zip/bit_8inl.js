var bit_8inl =
[
    [ "highestBitValue", "bit_8inl.html#ga0dcc8fe7c3d3ad60dea409281efa3d05", null ],
    [ "highestBitValue", "bit_8inl.html#ga898ef075ccf809a1e480faab48fe96bf", null ],
    [ "lowestBitValue", "bit_8inl.html#ga2ff6568089f3a9b67f5c30918855fc6f", null ],
    [ "lowestBitValue", "bit_8inl.html#a1f1ffbc1179f77df9c5db1eea899754c", null ],
    [ "powerOfTwoAbove", "bit_8inl.html#a4f29a0e902ea0e3a76fc10c5b0ef31b6", null ],
    [ "powerOfTwoAbove", "bit_8inl.html#ga2bbded187c5febfefc1e524ba31b3fab", null ],
    [ "powerOfTwoBelow", "bit_8inl.html#a895c5bb540f5f52ef2b7a81321a98627", null ],
    [ "powerOfTwoBelow", "bit_8inl.html#gaf78ddcc4152c051b2a21e68fecb10980", null ],
    [ "powerOfTwoNearest", "bit_8inl.html#a90d716367872062cffce4a8cd51acd0c", null ],
    [ "powerOfTwoNearest", "bit_8inl.html#gac87e65d11e16c3d6b91c3bcfaef7da0b", null ]
];