var classglm_1_1io_1_1basic__format__saver =
[
    [ "basic_format_saver", "classglm_1_1io_1_1basic__format__saver.html#a9688fa6dce0c32285527df2336ca9127", null ],
    [ "~basic_format_saver", "classglm_1_1io_1_1basic__format__saver.html#a49d58d91548a071d5f660c74ca88979b", null ]
];