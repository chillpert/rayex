var classglm_1_1io_1_1basic__state__saver =
[
    [ "basic_state_saver", "classglm_1_1io_1_1basic__state__saver.html#ab31652b0b7f2a24fa8f9fda2505de356", null ],
    [ "~basic_state_saver", "classglm_1_1io_1_1basic__state__saver.html#ad89569bbaec5d7fe08d40dbac5abbb53", null ]
];