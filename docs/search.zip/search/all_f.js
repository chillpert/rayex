var searchData=
[
  ['quadratic_263',['quadratic',['../struct_r_a_y_e_x_e_c___n_a_m_e_s_p_a_c_e_1_1_point_light.html#a4dc4113ea89c2f964ecdc4fa1832342c',1,'RAYEXEC_NAMESPACE::PointLight']]]
];
