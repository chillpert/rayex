var searchData=
[
  ['sdl_5fmain_5fhandled_814',['SDL_MAIN_HANDLED',['../_core_8hpp.html#a51f528deaaeb973f417b46a2ec36f850',1,'Core.hpp']]]
];
