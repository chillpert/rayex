var searchData=
[
  ['vk_5fenable_5fbeta_5fextensions_13443',['VK_ENABLE_BETA_EXTENSIONS',['../_core_8hpp.html#ae0ee52a031cc79e2e1b15516ed6ca362',1,'Core.hpp']]],
  ['vulkan_5fhpp_5fdispatch_5floader_5fdynamic_13444',['VULKAN_HPP_DISPATCH_LOADER_DYNAMIC',['../_core_8hpp.html#a8a27aa48a7a8781a30ab45040cb1dea7',1,'Core.hpp']]]
];
