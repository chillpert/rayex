var searchData=
[
  ['defaultp_12489',['defaultp',['../namespaceglm.html#a36ed105b07c7746804d7fdc7cc90ff25a9d21ccd8b5a009ec7eb7677befc3bf51',1,'glm']]]
];
