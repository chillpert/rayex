var searchData=
[
  ['lowp_13027',['lowp',['../namespaceglm.html#a36ed105b07c7746804d7fdc7cc90ff25ae161af3fc695e696ce3bf69f7332bc2d',1,'glm']]]
];
