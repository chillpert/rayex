var searchData=
[
  ['mediump_13028',['mediump',['../namespaceglm.html#a36ed105b07c7746804d7fdc7cc90ff25a6416f3ea0c9025fb21ed50c4d6620482',1,'glm']]]
];
