var searchData=
[
  ['newframe_620',['newFrame',['../class_r_a_y_e_x_e_c___n_a_m_e_s_p_a_c_e_1_1_gui.html#a7540ec605ab9247a035203511894e161',1,'RAYEXEC_NAMESPACE::Gui']]]
];
