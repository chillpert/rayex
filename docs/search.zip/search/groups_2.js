var searchData=
[
  ['exponential_20functions_13448',['Exponential functions',['../group__core__func__exponential.html',1,'']]],
  ['ext_5fmatrix_5fuint2x3_13449',['Ext_matrix_uint2x3',['../group__ext__matrix__uint2x3.html',1,'']]],
  ['ext_5fmatrix_5fuint3x2_13450',['Ext_matrix_uint3x2',['../group__ext__matrix__uint3x2.html',1,'']]]
];
