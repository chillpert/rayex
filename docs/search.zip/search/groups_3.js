var searchData=
[
  ['floating_2dpoint_20pack_20and_20unpack_20functions_13451',['Floating-Point Pack and Unpack Functions',['../group__core__func__packing.html',1,'']]]
];
