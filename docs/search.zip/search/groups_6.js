var searchData=
[
  ['matrix_20functions_13615',['Matrix functions',['../group__core__func__matrix.html',1,'']]],
  ['matrix_20types_13616',['Matrix types',['../group__core__matrix.html',1,'']]],
  ['matrix_20types_20with_20precision_20qualifiers_13617',['Matrix types with precision qualifiers',['../group__core__matrix__precision.html',1,'']]]
];
