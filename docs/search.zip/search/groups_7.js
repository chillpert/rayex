var searchData=
[
  ['recommended_20extensions_13618',['Recommended extensions',['../group__gtc.html',1,'']]]
];
