var indexSectionsWithContent =
{
  0: "abcdefghijlmnopqrstuvwy~",
  1: "abcdgilmprstuvw",
  2: "rsv",
  3: "abcdghiprstuvw",
  4: "abcdefgilmnoprstuvw~",
  5: "abcdefghijlmnopqrstuvwy",
  6: "p",
  7: "e",
  8: "apr",
  9: "grsv",
  10: "iv",
  11: "rt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "related",
  9: "defines",
  10: "groups",
  11: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator",
  8: "Friends",
  9: "Macros",
  10: "Modules",
  11: "Pages"
};

