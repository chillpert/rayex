var searchData=
[
  ['glyphrangesbuilder_11161',['GlyphRangesBuilder',['../struct_im_font_atlas.html#aa9b2fa0610903d5da7d9dfbfad3393af',1,'ImFontAtlas']]]
];
