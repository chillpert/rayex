var searchData=
[
  ['quat_12302',['quat',['../group__ext__quaternion__float.html#ga8f3c5f30982cc471ce0ac3eb737113b5',1,'glm']]],
  ['qword_12303',['qword',['../group__gtx__raw__data.html#ga32447af289e879589883c9b7e3be1246',1,'glm']]]
];
