var searchData=
[
  ['clearcolor_698',['clearColor',['../struct_r_a_y_e_x_e_c___n_a_m_e_s_p_a_c_e_1_1_ray_trace_push_constants.html#ac4ef828d926eeef4f40609122b70b845',1,'RAYEXEC_NAMESPACE::RayTracePushConstants']]],
  ['color_699',['color',['../struct_r_a_y_e_x_e_c___n_a_m_e_s_p_a_c_e_1_1_vertex.html#aff8b7f0bd8933579186b601fc8c48a7c',1,'RAYEXEC_NAMESPACE::Vertex']]],
  ['constant_700',['constant',['../struct_r_a_y_e_x_e_c___n_a_m_e_s_p_a_c_e_1_1_point_light.html#afc90ee1a8940d623808126054c36dd6d',1,'RAYEXEC_NAMESPACE::PointLight']]]
];
